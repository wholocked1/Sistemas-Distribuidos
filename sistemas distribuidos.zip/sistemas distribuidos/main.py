from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

tarefas = list()

class Tarefa(BaseModel):
    nome: str
    numero: int

@app.get("/")
def root():
    return tarefas


@app.get("/contato/{nome}")
def get_lista(nome: str):
    pos = len(tarefas)
    for n in tarefas:
        if n.nome == nome:
            pos = tarefas.index(n)
            break
    return tarefas[pos]

@app.post("/adicionar/")
def criar_contato(tarefa: Tarefa):
    tarefas.append(tarefa)
    return len(tarefas)

@app.put("/alterar_numero/{pos}")
def alterar_contato(nome: str, numeros: int):
    for n in tarefas:
        if n.nome == nome:
            pos = tarefas.index(n)
            break
    tarefas[pos].numero = numeros
    return tarefas[pos]

@app.put("/alterar_nome/{pos}")
def alterar_contato(nome_antigo: str, nome_novo: str):
    for n in tarefas:
        if n.nome == nome_antigo:
            pos = tarefas.index(n)
            break
    tarefas[pos].nome = nome_novo
    return tarefas[pos]

@app.delete("/deletar/{pos}")
def deletar_contato(nome: str):
    for n in tarefas:
        if n.nome == nome:
            pos = tarefas.index(n)
            break
    tarefa = tarefas.pop(pos)
    return tarefa
