import grpc
import calculadora_pb2
import calculadora_pb2_grpc

print("Cliente conectando com servidor")

porta = "50051"
endereco = "localhost"

with grpc.insecure_channel(f"{endereco}:{porta}") as channel:
    print("Escolha uma operação: \n1. Soma\n2. Subtração\n3. Multiplicação\n4.Divisão\n")
    acao = int(input())
    print("Primeiro valor:\n")
    valor1 = int(input())
    print("Segundo valor:\n")
    valor2 = int(input())
    stub = calculadora_pb2_grpc.CalcStub(channel)
    valor = calculadora_pb2.valores(valor1 =  valor1,valor2 = valor2)
    if acao == 1:
        resultado = stub.Soma(valor)
    elif acao == 2:
        resultado = stub.Subtracao(valor)
    elif acao == 3:
        resultado = stub.Multiplicacao(valor)
    else:
        resultado = stub.Divisao(valor)
    print(f"Resposta do servidor: {resultado.Resultado}")
